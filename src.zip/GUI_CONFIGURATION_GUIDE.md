# UJobs GUI Configuration Examples
# This file demonstrates all the new GUI customization features added to UJobs
# Author: GitHub Copilot
# Date: 2026

# ============================================
# FEATURES ADDED:
# ============================================
# 1. Custom Model Data Support - Add custom_model_data to any GUI item
# 2. Hex Color Support - Use both &#RRGGBB and &x&R&R&G&G&B&B formats
# 3. Standard Minecraft Colors - Use &a, &c, &e, etc.
# 4. GUI Protection - Prevent players from taking items from GUIs
# 5. Flexible GUI Configuration - Customize all aspects of GUIs

# ============================================
# COLOR FORMAT EXAMPLES:
# ============================================
# 
# Standard Minecraft Colors:
# &0 - Black       &8 - Dark Gray
# &1 - Dark Blue   &9 - Blue
# &2 - Dark Green  &a - Green
# &3 - Dark Aqua   &b - Aqua
# &4 - Dark Red    &c - Red
# &5 - Dark Purple &d - Light Purple
# &6 - Gold        &e - Yellow
# &7 - Gray        &f - White
#
# Formatting Codes:
# &k - Obfuscated  &l - Bold
# &m - Strikethrough &n - Underlined
# &o - Italic      &r - Reset
#
# Hex Colors (both formats work):
# &#00FF6E        - Short format
# &x&0&0&F&F&6&E  - Long format
#
# Examples:
# display_name: '&x&0&0&F&F&6&E&lCOOL TEXT'  # Hex color + bold
# display_name: '&#00FF6E&lCOOL TEXT'        # Same as above (short format)
# display_name: '&a&lGREEN TEXT'             # Standard green + bold
# display_name: '&c&nRED UNDERLINED'         # Standard red + underlined

# ============================================
# CUSTOM MODEL DATA EXAMPLES:
# ============================================
#
# Add custom model data to any item in the GUI:
#
# Example 1 - Basic item with custom model:
# my_item:
#   material: DIAMOND
#   slot: 10
#   custom_model_data: 1001  # Your resource pack model ID
#   display_name: '&x&0&0&F&F&6&ECustom Diamond'
#   lore:
#     - '&7This uses a custom model!'
#
# Example 2 - Navigation arrows with custom models:
# navigation:
#   left:
#     material: ARROW
#     custom_model_data: 5001  # Left arrow model
#     display_name: '&x&0&0&F&F&6&Eʙᴀᴄᴋ'
#   right:
#     material: ARROW
#     custom_model_data: 5002  # Right arrow model
#     display_name: '&x&0&0&F&F&6&Eɴᴇxᴛ'
#
# Example 3 - Player head with custom model:
# player_head:
#   material: PLAYER_HEAD
#   skull_owner: 'PlayerName'
#   custom_model_data: 2001
#   display_name: '&#FF6E00%player%''s Head'
#
# Set custom_model_data to 0 or remove it to disable

# ============================================
# GUI PROTECTION CONFIGURATION:
# ============================================
#
# Protects GUIs from unwanted interactions:
#
gui_protection:
  enabled: true                 # Master switch for GUI protection
  cancel_clicks: true           # Cancel all clicks in GUI
  cancel_shift_clicks: true     # Cancel shift-clicks
  cancel_drag: true             # Cancel dragging items to/from GUI

# ============================================
# FULL GUI CONFIGURATION EXAMPLE:
# ============================================
#
# This example shows how you can customize every aspect of your GUIs:
#
example_gui:
  size: 54                      # Inventory size (must be multiple of 9)
  menu_title: '&x&0&0&F&F&6&Eᴍʏ ᴄᴜsᴛᴏᴍ ɢᴜɪ'  # Supports hex colors
  
  # Background/border items
  border:
    material: GRAY_STAINED_GLASS_PANE
    custom_model_data: 0        # Optional custom model
    display_name: ' '           # Empty name
    slots: [0, 1, 2, 3, 4, 5, 6, 7, 8]  # Slots to fill
  
  # Static GUI items
  items:
    info_button:
      material: SUNFLOWER
      slot: 13
      custom_model_data: 1234   # Your custom model ID
      display_name: '&x&F&F&E&3&0&0ɪɴғᴏʀᴍᴀᴛɪᴏɴ'
      lore:
        - ''
        - '&#00FF6EClick for more info'  # Hex color in lore
        - '&7Gray text here'              # Standard color in lore
        - ''
    
    close_button:
      material: BARRIER
      slot: 49
      custom_model_data: 5678
      display_name: '&c&lᴄʟᴏsᴇ'
      lore:
        - '&7Click to close this menu'
  
  # Navigation buttons
  navigation:
    previous:
      material: ARROW
      slot: 45
      custom_model_data: 9001   # Custom left arrow model
      display_name: '&x&0&0&F&F&6&E&l←'
      lore:
        - '&fPrevious page'
    
    next:
      material: ARROW
      slot: 53
      custom_model_data: 9002   # Custom right arrow model
      display_name: '&x&0&0&F&F&6&E&l→'
      lore:
        - '&fNext page'

# ============================================
# INTEGRATION WITH EXISTING UJOBS CONFIG:
# ============================================
#
# The existing config.yml now supports:
#
# 1. Custom model data on blank items:
gui:
  blank_material: ORANGE_STAINED_GLASS_PANE
  blank_custom_model_data: 0    # Add your custom model ID here

# 2. Custom model data on job items:
gui:
  jobitem:
    custom_model_data: 0        # Add custom model for job icons

# 3. Custom model data on navigation:
gui:
  navigation:
    left:
      material: ARROW
      custom_model_data: 0      # Custom left arrow
      name: "<yellow><-"
      lore:
        - "&7Previous page"
    right:
      material: ARROW
      custom_model_data: 0      # Custom right arrow
      name: "<yellow>->"
      lore:
        - "&7Next page"

# ============================================
# UTILITIES AVAILABLE FOR DEVELOPERS:
# ============================================
#
# 1. ColorUtil.java
#    - colorize(String text) - Converts & codes to colors
#    - legacyToMiniMessage(String text) - Converts to MiniMessage format
#    - toComponent(String text) - Creates Component from colored text
#    - stripColors(String text) - Removes all color codes
#
# 2. GUIItemBuilder.java
#    - Builder pattern for creating GUI items
#    - Supports custom model data, hex colors, player heads, etc.
#    
#    Example usage:
#    ItemStack item = new GUIItemBuilder(Material.DIAMOND)
#        .name("&x&0&0&F&F&6&ECool Diamond")
#        .lore("&#FF0000Line 1", "&aLine 2")
#        .customModelData(1001)
#        .glow()
#        .build();
#
# 3. Enhanced GUI Protection
#    - Configurable via gui_protection section
#    - Prevents clicks, shift-clicks, and dragging
#    - Per-GUI customization possible

# ============================================
# NOTES:
# ============================================
#
# - All existing GUIs (MainJobGUI, LeaderboardGUI, JobInfoGUI) now support custom model data
# - MiniMessage format is still fully supported alongside & color codes
# - Hex colors work in both display names and lore
# - GUI protection is enabled by default but can be disabled
# - Set custom_model_data to 0 to disable it for any item

# ============================================
# RESOURCE PACK SETUP:
# ============================================
#
# To use custom model data:
# 1. Create your custom models in your resource pack
# 2. Assign custom_model_data predicates in your item's model JSON
# 3. Set the custom_model_data value in config.yml to match
# 4. Apply your resource pack to the server
#
# Example model JSON predicate:
# {
#   "parent": "item/generated",
#   "textures": {
#     "layer0": "item/diamond"
#   },
#   "overrides": [
#     {
#       "predicate": {
#         "custom_model_data": 1001
#       },
#       "model": "item/custom_diamond"
#     }
#   ]
# }
