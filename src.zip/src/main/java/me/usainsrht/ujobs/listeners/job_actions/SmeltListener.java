package me.usainsrht.ujobs.listeners.job_actions;

import org.bukkit.event.Listener;
import org.bukkit.event.inventory.FurnaceExtractEvent;

public class SmeltListener implements Listener {


    public void onSmelt(FurnaceExtractEvent e) {
        //todo smelt action
    }

}
