package me.usainsrht.ujobs.models;

public interface EntityAction extends Action {
}
