package me.usainsrht.ujobs.models;

public interface SpecialAction extends Action {
}
