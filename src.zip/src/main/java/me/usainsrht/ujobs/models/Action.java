package me.usainsrht.ujobs.models;

public interface Action {

    String getName();

}
