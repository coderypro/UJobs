package me.usainsrht.ujobs.models;

public interface MaterialAction extends Action {
}
