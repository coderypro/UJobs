package me.usainsrht.ujobs.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.util.concurrent.TimeUnit;

/**
 * Scheduler utility that provides compatibility between Paper and Folia
 * Automatically detects Folia and uses appropriate scheduler
 */
public class SchedulerUtil {

    private static final boolean IS_FOLIA;

    static {
        boolean folia;
        try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            folia = true;
        } catch (ClassNotFoundException e) {
            folia = false;
        }
        IS_FOLIA = folia;
    }

    /**
     * Check if running on Folia
     *
     * @return true if Folia, false if Paper/Spigot
     */
    public static boolean isFolia() {
        return IS_FOLIA;
    }

    /**
     * Run a task on the main thread (or appropriate region thread on Folia)
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     */
    public static void runTask(Plugin plugin, Runnable task) {
        if (IS_FOLIA) {
            Bukkit.getGlobalRegionScheduler().run(plugin, scheduledTask -> task.run());
        } else {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    /**
     * Run a task asynchronously
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     */
    public static void runTaskAsync(Plugin plugin, Runnable task) {
        if (IS_FOLIA) {
            Bukkit.getAsyncScheduler().runNow(plugin, scheduledTask -> task.run());
        } else {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, task);
        }
    }

    /**
     * Run a task after a delay
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     * @param delay  Delay in ticks (20 ticks = 1 second)
     */
    public static void runTaskLater(Plugin plugin, Runnable task, long delay) {
        if (IS_FOLIA) {
            Bukkit.getGlobalRegionScheduler().runDelayed(plugin, scheduledTask -> task.run(), delay);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, task, delay);
        }
    }

    /**
     * Run a task asynchronously after a delay
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     * @param delay  Delay in ticks
     */
    public static void runTaskLaterAsync(Plugin plugin, Runnable task, long delay) {
        if (IS_FOLIA) {
            long delayMs = delay * 50; // Convert ticks to milliseconds
            Bukkit.getAsyncScheduler().runDelayed(plugin, scheduledTask -> task.run(), delayMs, TimeUnit.MILLISECONDS);
        } else {
            Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, task, delay);
        }
    }

    /**
     * Run a repeating task
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     * @param delay  Initial delay in ticks
     * @param period Period between executions in ticks
     */
    public static void runTaskTimer(Plugin plugin, Runnable task, long delay, long period) {
        if (IS_FOLIA) {
            Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, scheduledTask -> task.run(), delay, period);
        } else {
            Bukkit.getScheduler().runTaskTimer(plugin, task, delay, period);
        }
    }

    /**
     * Run a repeating task asynchronously
     *
     * @param plugin Plugin instance
     * @param task   Task to run
     * @param delay  Initial delay in ticks
     * @param period Period between executions in ticks
     */
    public static void runTaskTimerAsync(Plugin plugin, Runnable task, long delay, long period) {
        if (IS_FOLIA) {
            long delayMs = delay * 50;
            long periodMs = period * 50;
            Bukkit.getAsyncScheduler().runAtFixedRate(plugin, scheduledTask -> task.run(), delayMs, periodMs, TimeUnit.MILLISECONDS);
        } else {
            Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, task, delay, period);
        }
    }

    /**
     * Run a task for a specific entity (Folia-aware)
     *
     * @param plugin Plugin instance
     * @param entity Entity to run task for
     * @param task   Task to run
     */
    public static void runEntityTask(Plugin plugin, Entity entity, Runnable task) {
        if (IS_FOLIA) {
            entity.getScheduler().run(plugin, scheduledTask -> task.run(), null);
        } else {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    /**
     * Run a task at a specific location (Folia-aware)
     *
     * @param plugin   Plugin instance
     * @param location Location to run task at
     * @param task     Task to run
     */
    public static void runLocationTask(Plugin plugin, Location location, Runnable task) {
        if (IS_FOLIA) {
            Bukkit.getRegionScheduler().run(plugin, location, scheduledTask -> task.run());
        } else {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    /**
     * Run a task for an entity after a delay
     *
     * @param plugin Plugin instance
     * @param entity Entity to run task for
     * @param task   Task to run
     * @param delay  Delay in ticks
     */
    public static void runEntityTaskLater(Plugin plugin, Entity entity, Runnable task, long delay) {
        if (IS_FOLIA) {
            entity.getScheduler().runDelayed(plugin, scheduledTask -> task.run(), null, delay);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, task, delay);
        }
    }

    /**
     * Run a task at a location after a delay
     *
     * @param plugin   Plugin instance
     * @param location Location to run task at
     * @param task     Task to run
     * @param delay    Delay in ticks
     */
    public static void runLocationTaskLater(Plugin plugin, Location location, Runnable task, long delay) {
        if (IS_FOLIA) {
            Bukkit.getRegionScheduler().runDelayed(plugin, location, scheduledTask -> task.run(), delay);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, task, delay);
        }
    }

    /**
     * Cancel all tasks for a plugin
     *
     * @param plugin Plugin instance
     */
    public static void cancelAllTasks(Plugin plugin) {
        if (!IS_FOLIA) {
            Bukkit.getScheduler().cancelTasks(plugin);
        }
        // On Folia, tasks are cancelled automatically when plugin is disabled
    }
}
