package me.usainsrht.ujobs.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Builder class for creating GUI items with support for:
 * - Custom model data
 * - Hex colors (&x&R&R&G&G&B&B)
 * - Standard Minecraft colors
 * - Player heads
 * - MiniMessage formatting
 */
public class GUIItemBuilder {

    private final ItemStack itemStack;
    private final ItemMeta meta;
    private MiniMessage miniMessage;
    private TagResolver[] placeholders;

    /**
     * Creates a new GUIItemBuilder
     * 
     * @param material The material of the item
     */
    public GUIItemBuilder(Material material) {
        this.itemStack = new ItemStack(material);
        this.meta = itemStack.getItemMeta();
        this.miniMessage = MiniMessage.miniMessage();
        this.placeholders = new TagResolver[0];
    }

    /**
     * Creates a new GUIItemBuilder from an existing ItemStack
     * 
     * @param itemStack The existing ItemStack
     */
    public GUIItemBuilder(ItemStack itemStack) {
        this.itemStack = itemStack;
        this.meta = itemStack.getItemMeta();
        this.miniMessage = MiniMessage.miniMessage();
        this.placeholders = new TagResolver[0];
    }

    /**
     * Sets the MiniMessage instance for parsing
     * 
     * @param miniMessage The MiniMessage instance
     * @return This builder
     */
    public GUIItemBuilder miniMessage(MiniMessage miniMessage) {
        this.miniMessage = miniMessage;
        return this;
    }

    /**
     * Sets the placeholders for MiniMessage parsing
     * 
     * @param placeholders The tag resolvers
     * @return This builder
     */
    public GUIItemBuilder placeholders(TagResolver... placeholders) {
        this.placeholders = placeholders;
        return this;
    }

    /**
     * Sets the display name with support for hex colors and MiniMessage
     * 
     * @param name The display name (supports &colors and MiniMessage)
     * @return This builder
     */
    public GUIItemBuilder name(String name) {
        if (name != null && !name.isEmpty()) {
            // Convert legacy colors to MiniMessage format
            String miniMessageText = ColorUtil.legacyToMiniMessage(name);
            Component component = miniMessage.deserialize(miniMessageText, placeholders)
                    .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
            meta.displayName(component);
        }
        return this;
    }

    /**
     * Sets the lore with support for hex colors and MiniMessage
     * 
     * @param lore The lore lines (supports &colors and MiniMessage)
     * @return This builder
     */
    public GUIItemBuilder lore(List<String> lore) {
        if (lore != null && !lore.isEmpty()) {
            List<Component> components = new ArrayList<>();
            for (String line : lore) {
                if (line != null) {
                    String miniMessageText = ColorUtil.legacyToMiniMessage(line);
                    Component component = miniMessage.deserialize(miniMessageText, placeholders)
                            .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
                    components.add(component);
                }
            }
            meta.lore(components);
        }
        return this;
    }

    /**
     * Sets the lore with support for hex colors and MiniMessage
     * 
     * @param lore The lore lines (supports &colors and MiniMessage)
     * @return This builder
     */
    public GUIItemBuilder lore(String... lore) {
        return lore(Arrays.asList(lore));
    }

    /**
     * Sets the custom model data
     * 
     * @param customModelData The custom model data value (0 to disable)
     * @return This builder
     */
    public GUIItemBuilder customModelData(int customModelData) {
        if (customModelData > 0) {
            meta.setCustomModelData(customModelData);
        }
        return this;
    }

    /**
     * Sets the amount of items
     * 
     * @param amount The amount
     * @return This builder
     */
    public GUIItemBuilder amount(int amount) {
        itemStack.setAmount(Math.max(1, Math.min(64, amount)));
        return this;
    }

    /**
     * Adds item flags
     * 
     * @param flags The flags to add
     * @return This builder
     */
    public GUIItemBuilder flags(ItemFlag... flags) {
        meta.addItemFlags(flags);
        return this;
    }

    /**
     * Hides all item flags
     * 
     * @return This builder
     */
    public GUIItemBuilder hideAll() {
        meta.addItemFlags(ItemFlag.values());
        return this;
    }

    /**
     * Makes the item glow (adds enchantment effect)
     * 
     * @return This builder
     */
    public GUIItemBuilder glow() {
        meta.setEnchantmentGlintOverride(true);
        return this;
    }

    /**
     * Sets the skull owner for player heads
     * 
     * @param playerName The player name
     * @return This builder
     */
    public GUIItemBuilder skullOwner(String playerName) {
        if (meta instanceof SkullMeta skullMeta && playerName != null && !playerName.isEmpty()) {
            skullMeta.setOwner(playerName);
        }
        return this;
    }

    /**
     * Hides the tooltip
     * 
     * @return This builder
     */
    public GUIItemBuilder hideTooltip() {
        meta.setHideTooltip(true);
        return this;
    }

    /**
     * Makes the item unbreakable
     * 
     * @return This builder
     */
    public GUIItemBuilder unbreakable() {
        meta.setUnbreakable(true);
        return this;
    }

    /**
     * Builds and returns the ItemStack
     * 
     * @return The built ItemStack
     */
    public ItemStack build() {
        itemStack.setItemMeta(meta);
        return itemStack;
    }

    /**
     * Static method to quickly create a simple item
     * 
     * @param material The material
     * @param name The display name
     * @return The ItemStack
     */
    public static ItemStack create(Material material, String name) {
        return new GUIItemBuilder(material).name(name).build();
    }

    /**
     * Static method to quickly create an item with lore
     * 
     * @param material The material
     * @param name The display name
     * @param lore The lore lines
     * @return The ItemStack
     */
    public static ItemStack create(Material material, String name, String... lore) {
        return new GUIItemBuilder(material).name(name).lore(lore).build();
    }

    /**
     * Static method to create an item with custom model data
     * 
     * @param material The material
     * @param name The display name
     * @param customModelData The custom model data
     * @return The ItemStack
     */
    public static ItemStack createWithModel(Material material, String name, int customModelData) {
        return new GUIItemBuilder(material).name(name).customModelData(customModelData).build();
    }
}
