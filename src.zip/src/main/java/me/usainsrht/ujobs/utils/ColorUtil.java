package me.usainsrht.ujobs.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for handling both hex colors (&x&R&R&G&G&B&B) and standard Minecraft color codes (&a, &c, etc.)
 */
public class ColorUtil {

    // Pattern for hex colors in format: &x&R&R&G&G&B&B or &#RRGGBB
    private static final Pattern HEX_PATTERN = Pattern.compile("&x(&[0-9a-fA-F]){6}");
    private static final Pattern SHORT_HEX_PATTERN = Pattern.compile("&#([0-9a-fA-F]{6})");
    
    // Standard Minecraft color codes
    private static final Pattern COLOR_PATTERN = Pattern.compile("&([0-9a-fk-or])");
    
    /**
     * Translates color codes in a string, supporting both:
     * - Hex colors: &x&R&R&G&G&B&B or &#RRGGBB
     * - Standard Minecraft colors: &0-9, &a-f, &k-o, &r
     * 
     * @param text The text to colorize
     * @return The colorized text
     */
    public static String colorize(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        // First convert short hex format &#RRGGBB to &x&R&R&G&G&B&B
        text = SHORT_HEX_PATTERN.matcher(text).replaceAll(result -> {
            String hex = result.group(1);
            StringBuilder builder = new StringBuilder("&x");
            for (char c : hex.toCharArray()) {
                builder.append("&").append(c);
            }
            return builder.toString();
        });
        
        // Then translate all color codes including hex
        return ChatColor.translateAlternateColorCodes('&', text);
    }
    
    /**
     * Converts legacy color codes to MiniMessage format
     * Useful for converting &x hex colors and & codes to <color:#RRGGBB> format
     * 
     * @param text The text with legacy color codes
     * @return The text in MiniMessage format
     */
    public static String legacyToMiniMessage(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        // Convert short hex format first
        text = SHORT_HEX_PATTERN.matcher(text).replaceAll(result -> {
            String hex = result.group(1);
            return "<color:#" + hex + ">";
        });
        
        // Convert &x&R&R&G&G&B&B format to <color:#RRGGBB>
        text = HEX_PATTERN.matcher(text).replaceAll(result -> {
            String matched = result.group(0);
            String hex = matched.replaceAll("&x|&", "");
            return "<color:#" + hex + ">";
        });
        
        // Convert standard color codes
        text = text.replaceAll("&0", "<black>")
                .replaceAll("&1", "<dark_blue>")
                .replaceAll("&2", "<dark_green>")
                .replaceAll("&3", "<dark_aqua>")
                .replaceAll("&4", "<dark_red>")
                .replaceAll("&5", "<dark_purple>")
                .replaceAll("&6", "<gold>")
                .replaceAll("&7", "<gray>")
                .replaceAll("&8", "<dark_gray>")
                .replaceAll("&9", "<blue>")
                .replaceAll("&a", "<green>")
                .replaceAll("&b", "<aqua>")
                .replaceAll("&c", "<red>")
                .replaceAll("&d", "<light_purple>")
                .replaceAll("&e", "<yellow>")
                .replaceAll("&f", "<white>")
                .replaceAll("&k", "<obfuscated>")
                .replaceAll("&l", "<bold>")
                .replaceAll("&m", "<strikethrough>")
                .replaceAll("&n", "<underlined>")
                .replaceAll("&o", "<italic>")
                .replaceAll("&r", "<reset>");
        
        return text;
    }
    
    /**
     * Creates a Component from text with legacy color codes
     * Supports both hex and standard Minecraft colors
     * 
     * @param text The text with color codes
     * @param miniMessage The MiniMessage instance
     * @return The colored Component
     */
    public static Component toComponent(String text, MiniMessage miniMessage) {
        if (text == null || text.isEmpty()) {
            return Component.empty();
        }
        
        // Convert legacy to MiniMessage format and then parse
        String miniMessageText = legacyToMiniMessage(text);
        return miniMessage.deserialize(miniMessageText);
    }
    
    /**
     * Creates a Component from text with legacy color codes using default MiniMessage
     * 
     * @param text The text with color codes
     * @return The colored Component
     */
    public static Component toComponent(String text) {
        return toComponent(text, MiniMessage.miniMessage());
    }
    
    /**
     * Strips all color codes from text
     * 
     * @param text The text to strip colors from
     * @return The text without color codes
     */
    public static String stripColors(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        return text.replaceAll("&x(&[0-9a-fA-F]){6}", "")
                .replaceAll("&#[0-9a-fA-F]{6}", "")
                .replaceAll("&[0-9a-fk-or]", "");
    }
}
