package me.usainsrht.ujobs.managers;

import me.usainsrht.ujobs.UJobsPlugin;
import me.usainsrht.ujobs.utils.SchedulerUtil;
import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class BossBarManager {
    private final UJobsPlugin plugin;
    private final Map<UUID, Map<String, BossBarData>> playerBossBars;
    private final Map<String, Object> taskIds; // Store task IDs for cancellation

    public BossBarManager(UJobsPlugin plugin) {
        this.plugin = plugin;
        this.playerBossBars = new ConcurrentHashMap<>();
        this.taskIds = new ConcurrentHashMap<>();
    }

    public void showBossBar(Player player, String key, BossBar bossBar, int durationSeconds) {
        UUID playerId = player.getUniqueId();

        // Get or create player's boss bar map
        Map<String, BossBarData> bossBars = playerBossBars.computeIfAbsent(playerId, k -> new HashMap<>());

        // Remove existing boss bar with same key
        BossBarData existing = bossBars.get(key);
        if (existing != null) {
            //hideBossBar(player, existing.bossBar);
            existing.bossBar.progress(bossBar.progress());
            existing.bossBar.name(bossBar.name());

            bossBar = existing.bossBar;
        } else {
            player.showBossBar(bossBar);
        }
        BossBar finalBossBar = bossBar;

        // Cancel existing task if present
        String taskKey = playerId.toString() + ":" + key;
        taskIds.remove(taskKey); // Mark old task as cancelled conceptually

        // Create hide task (Folia-compatible)
        SchedulerUtil.runEntityTaskLater(plugin, player, () -> {
            hideBossBar(player, finalBossBar);
            bossBars.remove(key);
            if (bossBars.isEmpty()) {
                playerBossBars.remove(playerId);
            }
            taskIds.remove(taskKey);
        }, durationSeconds * 20L);

        // Store boss bar data
        bossBars.put(key, new BossBarData(bossBar));
        taskIds.put(taskKey, true);
    }

    public void hideBossBar(Player player, BossBar bossBar) {
        player.hideBossBar(bossBar);
    }

    public void hideBossBar(Player player, String key) {
        UUID playerId = player.getUniqueId();
        Map<String, BossBarData> bossBars = playerBossBars.get(playerId);

        if (bossBars != null) {
            BossBarData bossBarData = bossBars.remove(key);
            if (bossBarData != null) {
                hideBossBar(player, bossBarData.bossBar);
            }

            if (bossBars.isEmpty()) {
                playerBossBars.remove(playerId);
            }
        }
    }

    public void removePlayerBossBars(Player player) {
        UUID playerId = player.getUniqueId();
        Map<String, BossBarData> bossBars = playerBossBars.remove(playerId);

        if (bossBars != null) {
            for (BossBarData bossBarData : bossBars.values()) {
                hideBossBar(player, bossBarData.bossBar);
            }
        }
    }

    public void removeAllBossBars() {
        for (UUID playerId : playerBossBars.keySet()) {
            Player player = plugin.getServer().getPlayer(playerId);
            if (player != null) {
                removePlayerBossBars(player);
            }
        }
        playerBossBars.clear();
    }

    public boolean hasBossBar(Player player, String key) {
        UUID playerId = player.getUniqueId();
        Map<String, BossBarData> bossBars = playerBossBars.get(playerId);
        return bossBars != null && bossBars.containsKey(key);
    }

    public void updateBossBar(Player player, String key, BossBar newBossBar) {
        UUID playerId = player.getUniqueId();
        Map<String, BossBarData> bossBars = playerBossBars.get(playerId);

        if (bossBars != null) {
            BossBarData existing = bossBars.get(key);
            if (existing != null) {
                // Hide old boss bar
                hideBossBar(player, existing.bossBar);

                // Show new boss bar
                player.showBossBar(newBossBar);

                // Update stored boss bar
                bossBars.put(key, new BossBarData(newBossBar));
            }
        }
    }

    private static class BossBarData {
        final BossBar bossBar;

        BossBarData(BossBar bossBar) {
            this.bossBar = bossBar;
        }
    }
}