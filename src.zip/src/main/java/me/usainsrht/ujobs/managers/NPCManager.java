package me.usainsrht.ujobs.managers;

import me.usainsrht.ujobs.UJobsPlugin;

public class NPCManager {

    public NPCManager(UJobsPlugin plugin) {

    }

}
