package me.usainsrht.ujobs.managers;

public class HologramManager {
}
